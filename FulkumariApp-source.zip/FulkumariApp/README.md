# Fulkumari Android WebView app

This Android Studio project loads https://fulkumari.com.np inside a WebView, keeps ordinary links in-app, and provides Back, Home, and Exit controls.

## Build APK
1. Install Android Studio (with Android SDK Platform 35).
2. Open this folder as a project and allow Gradle sync.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Note: this is a fresh WebView project, not a patched/re-signed copy of the uploaded APK. Some website features (uploads, downloads, camera, payment popups, or external app links) may need additional Android handling/testing.
