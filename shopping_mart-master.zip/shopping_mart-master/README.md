Contributed to Twowaits by Achintya (https://github.com/vibrantachintya) for educational purposes.

Ecommerce project made using Python, DJango and SQL Database. 

You can add projects with all details, add them to cart and place order.
