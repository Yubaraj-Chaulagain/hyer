function hideMessage(ele) {
    ele.style.display = 'none';
}

